package generics;

public class HasMultilevelArguments <T extends java.util.List<java.util.Map<String,Integer>>>{
 
}
