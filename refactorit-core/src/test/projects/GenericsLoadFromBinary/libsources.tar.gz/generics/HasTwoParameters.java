package generics;

public class HasTwoParameters<T1, T2 extends java.util.List & java.util.Set> {
  
  public HasTwoParameters() {
  }
  
}
