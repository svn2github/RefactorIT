package generics;

/*
 * fortest.java
 *
 * Created on November 29, 2004, 1:50 PM
 */

/**
 *
 * @author  ars
 */
public class HasOneSimpleParameter<T> {
  
  public HasOneSimpleParameter() {
  }
  
}
