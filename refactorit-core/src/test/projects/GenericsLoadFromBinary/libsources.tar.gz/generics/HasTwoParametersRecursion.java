package generics;

public class HasTwoParametersRecursion<T1 extends A<T1,T2>,T2 extends B<T1,T2>> {
  
  /** Creates a new instance of HasTwoParametersRecursion */
  public HasTwoParametersRecursion() {
  }
  
}

class A<T1, T2>{
  
}

class B<T1, T2>{
  
}
