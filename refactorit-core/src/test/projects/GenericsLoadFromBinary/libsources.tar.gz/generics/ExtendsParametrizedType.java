package generics;

public class ExtendsParametrizedType <W1, W2> extends java.util.ArrayList<java.util.Map<W1,W2>> {

}
