package generics;

public class InnerClassParameters <T extends java.util.List> {
  
  public class InnerClassA <F extends T>{
    
  }
  
  public class InnerClassB <S extends java.util.Set>{
    
  }
  
  public static class InnerStaticClass {
    public InnerStaticClass(int c){
      
    }
    
    public InnerStaticClass(InnerStaticClass a, int c){
      
    }
  }
  
}
