package generics;

public class ParametrizedMembers <TYPE1 extends java.util.List, 
    TYPE2 extends java.util.Set> {
  TYPE1 a = null;
  TYPE2 b = null;
  
  public ParametrizedMembers(TYPE1 a, TYPE2 b){}
  
  public TYPE1 returnsType1(TYPE2 getsType2){ return null; }
  
  public <MTYPE> TYPE1 getsMtype(MTYPE z){ return null; }
  
}
